#!/bin/bash
#Declare first string
string1="Welcome"
#Declare second string
string2=" everyone "
#Combine first and second string
string3=$string1$string2
# Print the third string by combining with other string
echo "$string3 to our site"
string4="etc_bkp_"$(date +%Y%m%d)".tar.gz"
#days="$(date +"%Y%m%d_%H%M")"
echo "$string4 -> archivo backup"


string5="/var/logs"


OUTPUT="a\'b\"c\`d_123and_a_lot_more"
OUTPUT=$(echo "$OUTPUT"|tr -d "'\`\"")
echo $OUTPUT

OUT2="$string5"
OUT2=$(echo "$OUT2"|tr -d "/\_")
echo $OUT2



