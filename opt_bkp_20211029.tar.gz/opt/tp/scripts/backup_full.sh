#!/bin/bash

LOG_FILE=backup_full.log
#exec 2>>${LOG_FILE}

function ayuda(){
    echo "Este script se utiliza para realizar backup comprimido"
    echo
    echo "Uso: ./backup_full.sh -o Origen -d Destino [-h Ayuda]"
    echo
    echo "-o es el archivo / directorio origen. Es obligatorio"
    echo "-d es la archivo / directorio destino. Es obligatorio"
    echo "-h es la ayuda del script. Es opcional"
    echo
}

function log {
  echo "$(date +%Y%m%d) - $1">>${LOG_FILE}
  #echo "$1">>${LOG_FILE}
}


log "Comensando ejecución script."
#echo "This is stderr. Written to log file only" 1>&2



while [[ $# -gt 0 ]]
do
    key="$1"

    case $key in
        -o|--origen)
            ORIGEN="$2"
            shift # past argument
            shift # past value
            ;;
        -d|--destino)
            DESTINO="$2"
            shift # past argument
            shift # past value
            ;;
        -h|--help)
	    HELP="$2"
            ayuda
            exit
            ;;
        *)
            echo "ERROR: parámetro desconocido"
            ayuda
            exit 1
            ;;
    esac
done

#echo "Origen: $ORIGEN"
#echo "Destino: $DESTINO"

if [ "$ORIGEN" == "" ]
then

  echo "ERROR: parámetro -o origen es obligatorio."
  exit 1

else

  if [ -d "$ORIGEN" ]; then
    echo "'$ORIGEN' encontrado."
  else
    echo "Atención: '$ORIGEN' no encontrado."
    exit 1
  fi

fi

if [ "$DESTINO" == "" ]
then

  echo "ERROR: parámetro -d destino es obligatorio."
  exit 1

else

  if [ -d "$DESTINO" ]; then
    echo "'$DESTINO' encontrado."
  else
    echo "Atención: '$DESTINO' no encontrado."
    exit 1
  fi

fi

ARCHIVO="$ORIGEN" 
ARCHIVO=$(echo "$ORIGEN"|tr -d "/\_"$(date +%Y%m%d)".tar.gz")

tar -czvf "$DESTINO/$ARCHIVO" "$ORIGEN"



#if [ "$HELP" == ""]
#then
#    ayuda
#    exit
#fi


