#!/bin/bash

LOG_FILE=backup_full.log

exec 2>>${LOG_FILE}


function log {
 echo "$(date +%Y%m%d) - $1">>${LOG_FILE}  
 #echo "$1">>${LOG_FILE}
}


log "Written to log file only"
echo "This is stderr. Written to log file only" 1>&2
