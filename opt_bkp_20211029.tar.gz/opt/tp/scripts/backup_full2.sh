#!/bin/bash

function ayuda(){
    echo "Este script se utiliza para realizar backup comprimido"
    echo
    echo "Uso: ./backup_full.sh -o Origen -d Destino [-h Ayuda]"
    echo
    echo "-o es el archivo / directorio origen. Es obligatorio"
    echo "-d es la archivo / directorio destino. Es obligatorio"
    echo "-h es la ayuda del script. Es opcional"
    echo
}


while [[ $# -gt 0 ]]
do
    key="$1"

    case $key in
        -o|--origen)
            OPCION1="$2"
            shift # past argument
            shift # past value
            ;;
        -d|--destino)
            OPCION2="$2"
            shift # past argument
            shift # past value
            ;;
        -h|--help)
            OPCION3="$2"
            shift # past argument
            shift # past value
            ;;
        -h|--help)
            ayuda
            exit
            ;;
        *)
            echo "ERROR: parámetro desconocido"
            ayuda
            exit 1
            ;;
    esac
done

echo "Opción 1: $OPCION1"
echo "Opción 2: $OPCION2"
echo "Opción 3: $OPCION3"

if [ "$OPCION3" == "" ]
then
    ayuda
    exit
fi


