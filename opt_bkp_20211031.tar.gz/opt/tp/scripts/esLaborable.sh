# !/usr/bin/bash

diasem=$1

esferiado=$(cat feriados.txt | grep $diasem )

dia=`echo ${diasem:0:2}`
mes=`echo ${diasem:2:2}`
anio=`echo ${diasem:4:7}`

fecha="$mes-$dia-$anio"
diasem=$(date -d $(echo $fecha|awk -F- '{print $3 "-" $1 "-" $2}') +%A)

if [ "$diasem" == "sábado" ] || [ "$diasem" == "domingo" ]; then
    echo "El $diasem es fin de semana"
elif [ "$esferiado" == "" ]; then
    echo "El $diasem es día laborable"
else
    echo "El $diasem es feriado"
fi

exit 0
