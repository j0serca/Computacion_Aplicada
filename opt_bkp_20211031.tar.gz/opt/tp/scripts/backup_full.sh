#!/bin/bash

function ayuda(){
    echo  
    echo "Este script se utiliza para realizar backup comprimido"
    echo
    echo "Uso: ./backup_full.sh -o Origen -d Destino [-h]"
    echo
    echo "-o Obligatorio. Es el directorio origen a comprimir" 
    echo "                y realizar backup"
    echo "-d Obligatorio. Es el directorio destino el archivo"
    echo "                comprimido del backup realizado"
    echo "-h Opcional. Para mostrar la ayuda del script." 
    echo
    echo "Ejemplos:"
    echo "    #bash backup_full.sh -o /etc -d /u03"
    echo "    #./backup_full.sh -h (con permisos de ejecución)"
    echo
}

function log {
  echo "$(date +"%Y-%m-%d %H:%M:%S") - $1">>${LOG_FILE}
  #echo "$1">>${LOG_FILE}
}

LOG_FILE=/opt/tp/scripts/backup_full.log
exec 2>>${LOG_FILE}


if [ -f $LOG_FILE  ]; then
  rm $LOG_FILE
fi

log "Inicio ejecución script."

while [[ $# -gt 0 ]]
do
    key="$1"

    case $key in
        -o|--origen)
            ORIGEN="$2"
            shift # past argument
            shift # past value
            ;;
        -d|--destino)
            DESTINO="$2"
            shift # past argument
            shift # past value
            ;;
        -h|--help)
	    HELP="$2"
            ayuda
            exit
            ;;
        *)
            log "ERROR: ('$key') parámetro desconocido."
            #echo "ERROR: ('$key') parámetro desconocido."
            exit 1
            ;;
    esac
done

if [ "$ORIGEN" == "" ]; then
  log "ERROR: parámetro -o origen es obligatorio."
  #echo "ERROR: parámetro -o origen es obligatorio."
  exit 1
else
  if [ ! -d "$ORIGEN" ]; then
    log "Atención: '$ORIGEN' no encontrado."
    #echo "Atención: '$ORIGEN' no encontrado."
    exit 1
  fi

fi

if [ "$DESTINO" == "" ]; then
  log "ERROR: parámetro -d destino es obligatorio."
  #echo "ERROR: parámetro -d destino es obligatorio."
  exit 1
else
  if [ ! -d "$DESTINO" ]; then
    log "Atención: '$DESTINO' no encontrado."
    #echo "Atención: '$DESTINO' no encontrado."
    exit 1
  fi
fi

ARCHIVO_EXTENSION=$(date +%Y%m%d)".tar.gz"
ARCHIVO="$(echo "$ORIGEN"|tr -d "/\_")_$ARCHIVO_EXTENSION"

log "Inicio de ejecutando: tar -czvf $DESTINO/$ARCHIVO $ORIGEN"

tar -czvf "$DESTINO/$ARCHIVO" "$ORIGEN" 1>/dev/null

if [ $? -eq 0 ]; then
  BODY_EMAIL="Fin de ejecución en forma correcta de: tar -czvf $DESTINO/$ARCHIVO $ORIGEN"
  log "$BODY_EMAIL"
else
  BODY_EMAIL="Fin de ejecución con error de: tar -czvf $DESTINO/$ARCHIVO $ORIGEN"
  log "$BODY_EMAIL"
fi

log "Inicio envío de email de notificación al administrador (root)"

echo "$BODY_EMAIL" | mutt -s "Email automático script: backup_full.sh" -a backup_full.log -- root@debian

if [ $? -eq 0 ]; then
  log "Fin de envío de email en forma correcta a root@debian"
else
  log "Fin de envío de email con error a root@debian"
fi

log "Fin ejecición script."
