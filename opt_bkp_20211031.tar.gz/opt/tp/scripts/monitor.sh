# !/usr/bin/bash

comando=$1

com_pid=$(pgrep $comando)

if [ "$com_pid" != "" ]; then
    mail -s "Proceso $comando en ejecución" root <<< "El proceso $comando está en ejecución"
else
    echo "El comando $comando no está en ejecución"
fi

exit 0
