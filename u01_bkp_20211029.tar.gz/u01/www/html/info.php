<html>
 <head>
  <title>Información del servidor PHP</title>
 </head>
 <body>
 <?php phpinfo(); ?>
 </body>
</html>
